% Tic Tac Toe Game

% Initialize the game board
board = [' ',' ',' ';' ',' ',' ';' ',' ',' '];

% Loop until there is a winner or the board is full
while true
    % Display the board
    disp(board);
    
    % Player 1's turn
    row = input('Player 1, enter row number (1-3): ');
    col = input('Player 1, enter column number (1-3): ');
    if board(row, col) == ' '
        board(row, col) = 'X';
    else
        disp('That spot is already taken!');
        continue;
    end
    
    % Check for a winner or a tie
    if check_winner(board, 'X')
        disp('Player 1 Wins!');
        break;
    elseif check_tie(board)
        disp('It is a tie!');
        break;
    end
    
    % Display the board
    disp(board);
    
    % Player 2's turn
    row = input('Player 2, enter row number (1-3): ');
    col = input('Player 2, enter column number (1-3): ');
    if board(row, col) == ' '
        board(row, col) = 'O';
    else
        disp('That spot is already taken!');
        continue;
    end
    
    % Check for a winner or a tie
    if check_winner(board, 'O')
        disp('Player 2 Wins!');
        break;
    elseif check_tie(board)
        disp('It is a tie!');
        break;
    end
end

% Check for a winner
function winner = check_winner(board, player)
    winner = false;
    for i = 1:3
        % Check rows
        if board(i, 1) == player && board(i, 2) == player && board(i, 3) == player
            winner = true;
            break;
        end
        
        % Check columns
        if board(1, i) == player && board(2, i) == player && board(3, i) == player
            winner = true;
            break;
        end
    end
    
    % Check diagonals
    if board(1, 1) == player && board(2, 2) == player && board(3, 3) == player
        winner = true;
    elseif board(1, 3) == player && board(2, 2) == player && board(3, 1) == player
        winner = true;
    end
end

% Check for a tie
function tie = check_tie(board)
    tie = true;
    for i = 1:3
        for j = 1:3
            if board(i, j) == ' '
                tie = false;
                break;
            end
        end
        if ~tie
            break;
        end
    end
end
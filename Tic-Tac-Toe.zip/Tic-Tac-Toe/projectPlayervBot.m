
% Tic Tac Toe Game

% Initialize the game board
board = ['-','-','-';'-','-','-';'-','-','-'];

% Ask the user to select bot difficulty
fprintf('Choose bot difficulty:\n1) Random bot\n2) Novice bot\n3) Intermediate bot\n4) Expert bot\n');
difficulty = input('Enter difficulty number (1-4): ');

% Loop until there is a winner or the board is full
while true

    % Display the board
    disp(board);

    % Bot's turn
    if difficulty == 1 % Random bot
    [row, col] = choose_random_move(board);
    elseif difficulty == 2 % Novice bot
    [row, col] = choose_novice_move(board);
    elseif difficulty == 3 % Intermediate bot
    [row, col] = choose_intermediate_move(board);
    elseif difficulty == 4 % Expert bot
    [row, col] = choose_expert_move(board);
    end

    board(row, col) = 'O';

    fprintf('Bot chooses row %d, column %d\n', row, col);

    % Check for a winner or a tie
    if check_winner(board, 'O')
    disp('Bot Wins!');
    break;
    elseif check_tie(board)
    disp('It is a tie!');
    break;
    end

    % Display the board
    disp(board);

    % Player 1's turn
    row = input('Player 1, enter row number (1-3): ');
    col = input('Player 1, enter column number (1-3): ');
    if board(row, col) == '-'
    board(row, col) = 'X';
    else
        disp('That spot is already taken!');
        continue;
    end

    % Check for a winner or a tie
    if check_winner(board, 'X')
        disp('Player 1 Wins!');
        break;
    elseif check_tie(board)
        disp('It is a tie!');
        break;
    end
end

% Check for a winner
function winner = check_winner(board, player)
    winner = false;
        for i = 1:3
        % Check rows
        if board(i, 1) == player && board(i, 2) == player && board(i, 3) == player
            winner = true;
            break;
        end
% Check columns
        if board(1, i) == player && board(2, i) == player && board(3, i) == player
        winner = true;
            break;
        end
        end
        % Check diagonals
    if board(1, 1) == player && board(2, 2) == player && board(3, 3) == player
        winner = true;
    elseif board(1, 3) == player && board(2, 2) == player && board(3, 1) == player
        winner = true;
    end
end

% Check for a tie
function tie = check_tie(board)
    tie = true;
    for i = 1:3
        for j = 1:3
            if board(i, j) == '-'
                tie = false;
                break;
            end
        end
        if ~tie
            break;
        end
    end
end

% Random Bot
function [row, col] = choose_random_move(board)
    while true
        row = randi(3);
        col = randi(3);
        if board(row, col) == '-'
            break;
        end
    end
end

% Novice Bot
function [row, col] = choose_novice_move(board)
    % Look for a winning move for the player and block it
    for i = 1:3
        for j = 1:3
            if board(i, j) == '-'
                % Check if placing here blocks the player
                board(i, j) = 'X';
                if check_winner(board, 'X')
                    board(i, j) = 'O';
                    row = i;
                    col = j;
                    return;
                else
                    board(i, j) = '-';
                end
            end
        end
    end
    
    % Otherwise, place randomly
    while true
        row = randi(3);
        col = randi(3);
        if board(row, col) == '-'
            break;
        end
    end
end
% Intermediate
function [row, col] = choose_intermediate_move(board)
    % First move: Place on a corner or center square
    if nnz(board) == 0
        corners = [1 1; 1 3; 3 1; 3 3];
        center = [2 2];
        choices = [corners; center];
        choice_idx = randi(size(choices, 1));
        row = choices(choice_idx, 1);
        col = choices(choice_idx, 2);
    else
        % Follow novice play strategy for all other moves
        [row, col] = choose_novice_move(board);
    end
end
% Expert
function [row, col] = choose_expert_move(board)
    % First move: Place on center square
    if nnz(board) == 0
        center = [2,2];
        row = center(1);
        col = center(2);
    else
        % Follow novice play strategy for all other moves
        [row, col] = choose_novice_move(board);
    end
end